
	<div class="container-fluid" id="content">
		<div id="left">
			
			<div class="subnav">
				<div class="subnav-title">
					<a href="#" class='toggle-subnav'>
						<i class="fa fa-angle-down"></i>
						<span>Dashboard</span>
					</a>
				</div>
				
			</div>
			
		
		</div>
		
		<div id="main">
			<div class="container-fluid">