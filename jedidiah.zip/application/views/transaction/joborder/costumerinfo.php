<div class="page-header">
	<div class="pull-left">
		<div class="row">
			<div class="col-sm-3">
				<img src="<?php echo base_url('assets/img/user-1.jpg') ?>" class="avatar avatar-md img-circle bordered" alt="">
			</div>
			
			<div class="col-sm-9">
				<h1>Costumer Name</h1>
			</div>
		</div>
	</div>
	<div class="pull-right">
		<ul class="stats">
			<li class='lightred'>
				<i class="fa fa-calendar"></i>
				<div class="details">
					<span class="big">BI-2014/1234</span>
					<span>February 4, 2015</span>
				</div>
			</li>
			<li class='satgreen'>
				<i class="fa fa-money"></i>
				<div class="details">
					<span class="big">BOOKING OPEN</span>
					<span>B2</span>
				</div>
			</li>
		</ul>
	</div>
</div>



<script>
	$(document).ready(function(){
		/*$("#group").editable({
			showbuttons:false
		});*/
	});

</script>